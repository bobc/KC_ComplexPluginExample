from complex_plugin_action import ComplexPluginAction
ComplexPluginAction().register() # Instantiate and register to Pcbnew
# This is run when the pcb editor is opened
# Note the relative import! See http://www.diveintopython3.net/porting-code-to-python-3-with-2to3.html#import
