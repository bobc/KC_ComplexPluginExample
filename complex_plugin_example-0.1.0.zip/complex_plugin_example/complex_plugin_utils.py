import pcbnew

def get_board():
    return pcbnew.GetBoard()
